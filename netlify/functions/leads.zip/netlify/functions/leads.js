var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var leads_exports = {};
__export(leads_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(leads_exports);
var import_fs = require("fs");
var import_path = require("path");
const ok = (v) => typeof v === "string" && v.trim().length > 0;
async function handler(event) {
  const query = new URLSearchParams(event.queryStringParameters).get("q") || "";
  const apiKey = process.env.APOLLO_KEY;
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json"
  };
  if (!ok(query)) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "missing_query" }) };
  }
  try {
    if (!ok(apiKey)) throw new Error("no_apollo_key");
    const apolloRes = await fetch("https://api.apollo.io/v1/people/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Api-Key": apiKey
      },
      body: JSON.stringify({
        q_keywords: query,
        // free-text search
        page: 1,
        per_page: 5
      })
    });
    if (!apolloRes.ok) throw new Error(`apollo_${apolloRes.status}`);
    const data = await apolloRes.json();
    const people = Array.isArray(data.people) ? data.people : [];
    const leads = people.slice(0, 5).map((p) => ({
      name: p.name || "",
      title: p.title || "",
      company: p.organization && p.organization.name || p.employer || "",
      email: p.email || "",
      phone: p.phone_number || "",
      city: p.city || "",
      website: p.organization && p.organization.website_url || ""
    }));
    if (leads.length) {
      return { statusCode: 200, headers, body: JSON.stringify({ leads }) };
    }
    throw new Error("empty_apollo");
  } catch (e) {
    try {
      const csvPath = (0, import_path.join)(process.cwd(), "data", "leads.csv");
      const raw = (0, import_fs.readFileSync)(csvPath, "utf8");
      const rows = raw.split(/\r?\n/).filter(Boolean);
      const [header, ...rest] = rows;
      const idx = Object.fromEntries(header.split(",").map((h, i) => [h.trim(), i]));
      const filtered = rest.map((line) => line.split(",")).filter((cols) => (cols[idx.city] || "").toLowerCase().includes(query.toLowerCase())).slice(0, 5).map((c) => ({
        name: "",
        title: "",
        company: c[idx.company] || "",
        email: c[idx.email] || "",
        phone: c[idx.phone] || "",
        city: c[idx.city] || "",
        website: c[idx.website] || ""
      }));
      return { statusCode: 200, headers, body: JSON.stringify({ leads: filtered }) };
    } catch (csvErr) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "leads_failed" }) };
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
