var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var email_exports = {};
__export(email_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(email_exports);
async function handler(event) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "method_not_allowed" })
    };
  }
  try {
    const { to, subject, html } = JSON.parse(event.body || "{}");
    if (!to || !subject || !html) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "missing_required_fields" })
      };
    }
    const RESEND_API_KEY = process.env.RESEND_API_KEY;
    const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
    const FROM_EMAIL = process.env.OUTBOUND_FROM_EMAIL;
    const FROM_NAME = process.env.OUTBOUND_FROM_NAME || "Outreach System";
    if (!FROM_EMAIL) {
      throw new Error("no_from_email_configured");
    }
    if (RESEND_API_KEY) {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${RESEND_API_KEY}`
        },
        body: JSON.stringify({
          from: `${FROM_NAME} <${FROM_EMAIL}>`,
          to: [to],
          subject,
          html
        })
      });
      if (!r.ok) {
        const t = await r.text();
        throw new Error(`resend_${r.status}_${t}`);
      }
      const result = await r.json();
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          ok: true,
          provider: "resend",
          id: result.id
        })
      };
    } else if (SENDGRID_API_KEY) {
      const r = await fetch("https://api.sendgrid.com/v3/mail/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SENDGRID_API_KEY}`
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: to }] }],
          from: { email: FROM_EMAIL, name: FROM_NAME },
          subject,
          content: [{ type: "text/html", value: html }]
        })
      });
      if (!r.ok) {
        const t = await r.text();
        throw new Error(`sendgrid_${r.status}_${t}`);
      }
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          ok: true,
          provider: "sendgrid"
        })
      };
    } else {
      throw new Error("no_email_provider_configured");
    }
  } catch (err) {
    console.error("Email sending error:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "send_failed",
        message: err.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
